<div id="firstcont" class="mxm-cont">
  <div class="mxm-cont-second">
    <img alt="Web Studio" id="mxm-illus" src="<?= base_url('assets/bg/form_illus.svg'); ?>" />
    <div>
      <h2>FORM LIST KEBUTUHAN<br> STATE 2020</h2>
      <div class="d-flex align-center justify-content-center mt-4">
        <a href="<?= base_url('state/formListKebutuhan'); ?>" class="mxm-btn-yellow">KLIK DISINI</a>
      </div>
    </div>
  </div>
</div>
<div>
  <svg class="mxm-wave" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#F4224B" fill-opacity="1" d="M0,160L48,165.3C96,171,192,181,288,165.3C384,149,480,107,576,101.3C672,96,768,128,864,149.3C960,171,1056,181,1152,197.3C1248,213,1344,235,1392,245.3L1440,256L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>
  <svg class="pt-0 mt-0" style="position:absolute;bottom:0;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#41CEBA" fill-opacity="1" d="M0,192L48,170.7C96,149,192,107,288,101.3C384,96,480,128,576,165.3C672,203,768,245,864,229.3C960,213,1056,139,1152,128C1248,117,1344,171,1392,197.3L1440,224L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>
  <svg class="pt-0 mt-0" style="position:absolute;bottom:0;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#FFD008" fill-opacity="1" d="M0,192L48,202.7C96,213,192,235,288,240C384,245,480,235,576,234.7C672,235,768,245,864,229.3C960,213,1056,171,1152,160C1248,149,1344,171,1392,181.3L1440,192L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>
</div>

